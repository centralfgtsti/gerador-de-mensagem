# Gerador de Mensagens — Crédito CLT & Saque-Aniversário FGTS

Ferramenta interna para correspondentes bancários: gera mensagens prontas de WhatsApp para ofertas de Crédito CLT (consignado privado) e antecipação do Saque-Aniversário do FGTS.

## Como funciona

- Escolha o produto (**Crédito CLT** ou **Saque-Aniversário FGTS**) e preencha nome, CPF e saldo — o CPF e o valor se formatam sozinhos enquanto digita.
- A mensagem é gerada em **duas partes** (corpo + pergunta final), cada uma com seu botão de copiar, para enviar em mensagens separadas ao cliente.
- **4 variações de texto** por produto — alterne entre elas a cada envio para as mensagens não saírem idênticas.
- Modo **"Cliente sem cadastro"**: mensagens de primeiro contato com apresentação do consultor. O texto se ajusta automaticamente ao gênero pelo nome do consultor (com seletor manual para corrigir).
- Variação 4 = mensagem de **reativação** ("Lembra de mim?"), disponível nos dois modos; o nome do cliente é opcional nela.

## Como publicar

É um único arquivo estático (`index.html`), sem dependências e sem backend.

**GitHub Pages:** Settings → Pages → Source: Deploy from a branch → branch `main`, pasta `/ (root)` → Save. O site sobe em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

**Netlify:** conecte este repositório em "Import from Git" (deploys automáticos a cada commit) ou arraste a pasta no painel.

## Editar as mensagens

Os textos ficam no `index.html`, nas constantes `T` (cliente cadastrado, CLT e FGTS) e `T_NOVO` (cliente sem cadastro). Marcadores usados nos templates:

| Marcador | Vira |
|----------|------|
| `{n}` | nome do cliente |
| `{c}` | nome do consultor |
| `{cpf}` | CPF formatado |
| `{v}` | valor em reais |
| `{saud}` | "Olá, Fulano!" ou "Olá!" (reativação) |
| `{art}` / `{cons}` | "a/o" e "consultora/consultor" conforme o gênero |
| `{conta}` | pergunta sobre a conta de depósito |
| `\|\|\|` | ponto de divisão entre a parte 1 e a parte 2 da mensagem |
